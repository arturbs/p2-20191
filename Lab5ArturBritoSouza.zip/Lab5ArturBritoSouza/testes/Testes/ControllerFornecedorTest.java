/**
 * 
 */
package Testes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * @author artur bs
 *
 */
class ControllerFornecedorTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#ControllerFornecedor()}.
	 */
	@Test
	final void testControllerFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#cadastraFornecedor(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testCadastraFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#encontraFornecedor(java.lang.String)}.
	 */
	@Test
	final void testEncontraFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#listarFornecedores()}.
	 */
	@Test
	final void testListarFornecedores() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#editaFornecedor(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testEditaFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#removeFornecedor(java.lang.String)}.
	 */
	@Test
	final void testRemoveFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#cadastraProduto(java.lang.String, java.lang.String, double, java.lang.String)}.
	 */
	@Test
	final void testCadastraProduto() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#encontraProduto(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testEncontraProduto() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#listaProdutosFornecedor(java.lang.String)}.
	 */
	@Test
	final void testListaProdutosFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#listarProdutosDeTodosOsFornecedores()}.
	 */
	@Test
	final void testListarProdutosDeTodosOsFornecedores() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#editaProduto(java.lang.String, java.lang.String, double, java.lang.String)}.
	 */
	@Test
	final void testEditaProduto() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerFornecedor#removeProduto(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testRemoveProduto() {
		fail("Not yet implemented"); // TODO
	}

}
