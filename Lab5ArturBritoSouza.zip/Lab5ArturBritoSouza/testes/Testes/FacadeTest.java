/**
 * 
 */
package Testes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * @author artur bs
 *
 */
class FacadeTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	/**
	 * Test method for {@link SAGA.Facade#Facade()}.
	 */
	@Test
	final void testFacade() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#main(java.lang.String[])}.
	 */
	@Test
	final void testMain() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#cadastraCliente(java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testCadastraCliente() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#encontraCliente(java.lang.String)}.
	 */
	@Test
	final void testEncontraCliente() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#listaClientes()}.
	 */
	@Test
	final void testListaClientes() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#editaCadastro(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testEditaCadastro() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#RemoveClienteDoCadastro(java.lang.String)}.
	 */
	@Test
	final void testRemoveClienteDoCadastro() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#cadastraFornecedor(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testCadastraFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#encontraFornecedor(java.lang.String)}.
	 */
	@Test
	final void testEncontraFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#listarFornecedores()}.
	 */
	@Test
	final void testListarFornecedores() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#editaFornecedor(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testEditaFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#removeFornecedor(java.lang.String)}.
	 */
	@Test
	final void testRemoveFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#cadastraProduto(java.lang.String, java.lang.String, double, java.lang.String)}.
	 */
	@Test
	final void testCadastraProduto() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#encontraProduto(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testEncontraProduto() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#listaProdutosFornecedor(java.lang.String)}.
	 */
	@Test
	final void testListaProdutosFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#editaProduto(java.lang.String, java.lang.String, double, java.lang.String)}.
	 */
	@Test
	final void testEditaProduto() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.Facade#removeProduto(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testRemoveProduto() {
		fail("Not yet implemented"); // TODO
	}

}
