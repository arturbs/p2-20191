/**
 * 
 */
package Testes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * @author artur bs
 *
 */
class IdentificadorProdutoTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	/**
	 * Test method for {@link SAGA.IdentificadorProduto#hashCode()}.
	 */
	@Test
	final void testHashCode() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.IdentificadorProduto#IdentificadorProduto(java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testIdentificadorProduto() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.IdentificadorProduto#equals(java.lang.Object)}.
	 */
	@Test
	final void testEqualsObject() {
		fail("Not yet implemented"); // TODO
	}

}
