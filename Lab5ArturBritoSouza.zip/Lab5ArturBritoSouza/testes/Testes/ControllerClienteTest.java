/**
 * 
 */
package Testes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * @author artur bs
 *
 */
class ControllerClienteTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	/**
	 * Test method for {@link SAGA.ControllerCliente#ControllerCliente()}.
	 */
	@Test
	final void testControllerCliente() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerCliente#cadastraCliente(java.lang.String, java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testCadastraCliente() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerCliente#encontraCliente(java.lang.String)}.
	 */
	@Test
	final void testEncontraCliente() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerCliente#listaClientes()}.
	 */
	@Test
	final void testListaClientes() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerCliente#editaCadastro(java.lang.String, java.lang.String, java.lang.String)}.
	 */
	@Test
	final void testEditaCadastro() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ControllerCliente#RemoveClienteDoCadastro(java.lang.String)}.
	 */
	@Test
	final void testRemoveClienteDoCadastro() {
		fail("Not yet implemented"); // TODO
	}

}
