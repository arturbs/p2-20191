/**
 * 
 */
package Testes;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

/**
 * @author Artur Brito Souza - UFCG 
 *
 */
class ProdutoDoFornecedorTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	/**
	 * Test method for {@link SAGA.ProdutoDoFornecedor#hashCode()}.
	 */
	@Test
	final void testHashCode() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ProdutoDoFornecedor#ProdutoDoFornecedor(java.lang.String, java.lang.String, double)}.
	 */
	@Test
	final void testProdutoDoFornecedor() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ProdutoDoFornecedor#getNome()}.
	 */
	@Test
	final void testGetNome() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ProdutoDoFornecedor#getDescricao()}.
	 */
	@Test
	final void testGetDescricao() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ProdutoDoFornecedor#setPreco(double)}.
	 */
	@Test
	final void testSetPreco() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ProdutoDoFornecedor#equals(java.lang.Object)}.
	 */
	@Test
	final void testEqualsObject() {
		fail("Not yet implemented"); // TODO
	}

	/**
	 * Test method for {@link SAGA.ProdutoDoFornecedor#toString()}.
	 */
	@Test
	final void testToString() {
		fail("Not yet implemented"); // TODO
	}

}
