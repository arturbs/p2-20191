package pacoteSCR;
/**
 * Programa Controle de Alunos.
 * @author Artur Brito Souza - 118210056 - UFCG
 */
public class Main {

	public static void main(String[] args) {
		
		Menu.exibeMenu();
		// TODO Auto-generated method stub

	}

}
