package testes;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pacoteSCR.Grupo;

class GrupoTeste {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
