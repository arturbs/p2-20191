package testes;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import pacoteSCR.Controlador;

class ControladorTeste {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
